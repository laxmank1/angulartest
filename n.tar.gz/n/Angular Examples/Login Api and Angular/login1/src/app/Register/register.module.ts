import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RegisterRoutingModule } from "./register-routing.module";
import { RegisterComponent } from "./register.component";
import { HttpModule } from "@angular/http";


@NgModule({
    imports: [
        CommonModule,
        RegisterRoutingModule,
        HttpModule
    ],
    declarations: [RegisterComponent]
})
export class RegisterModule {
}
