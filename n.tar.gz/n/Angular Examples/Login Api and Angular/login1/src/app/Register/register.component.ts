import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { Http,Headers,RequestOptions } from "@angular/http";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

    constructor(private _router: Router,private _http: Http) {
    }
    ngOnInit() {
      
    }
      register(event, email, password,confirmpassword) {
        event.preventDefault();
         
        let url = "http://localhost:50138/api/Account/Register";
        let body = "email=" + email + "&password=" + password + "&confirmpassword="+ confirmpassword;
        let headers = new Headers({ 'content-type': 'application/x-www-form-urlencoded' });
        let options = new RequestOptions({ headers: headers });     

        this._http.post(url,body,options).subscribe(
            response => {
                 alert("Registration successfully done");
                this._router.navigate(['login']);
            },
            error => {
                alert(error.text());
                console.log(error.text());
            }
        );
    }    
  
}
