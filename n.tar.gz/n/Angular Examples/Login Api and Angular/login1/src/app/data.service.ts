import { Injectable } from '@angular/core';
import { Http, Headers, Request, RequestOptions } from "@angular/http";

@Injectable()
export class DataService {
private url=''
  constructor(private http:Http) { }

// createPost(event, username, password){
//         event.preventDefault();
//         let url = "http://localhost:50138/Token";
//         let body = "username=" + username + "&password=" + password + "&grant_type=password";
//         let headers = new Headers({ 'content-type': 'application/x-www-form-urlencoded' });
//         let options = new RequestOptions({ headers: headers });     

//     return this.http.post(url,body,options)
//     .map(response=>response.json())
//   }
}
